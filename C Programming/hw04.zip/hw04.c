/*5.23
#include <stdio.h>
#include <math.h>

int second(int hour, int min, int sec);

void main() {
	printf("Please input the first time's hour minute second:");
	int hour1, min1, sec1;
	scanf_s("%d %d %d", &hour1, &min1, &sec1);//�����һ��ʱ��
	printf("Please input the second time's hour minute second:");
	int hour2, min2, sec2;
	scanf_s("%d %d %d", &hour2, &min2, &sec2);//����ڶ���ʱ��

	int second1 = second(hour1, min1, sec1);
	int second2 = second(hour2, min2, sec2);
	int result = second2 - second1;
	result = fabs(result);//ת��Ϊ����ֵ
	printf("The time interval is��%d second\n", result);
	system("pause");
}

int second(int hour, int min, int sec) {
	int second;
	second = hour * 3600 + min * 60 + sec;//��ʱ��ת��Ϊ����Ϊ��λ
	return second;
}
*/

/*5.27*/
//
//#include <stdio.h>
//#include <math.h>
//
//int isprime(int input) {//�ж��Ƿ�Ϊ���������򷵻�0
//
//	int i = 2, temp = 0;
//	for (; i <= sqrt(input); i++) {
//		if (input%i == 0) {
//			temp = 1;
//			break;
//		}
//	}
//	return temp;
//}
//
//void main() {
//	int i;
//	int temp = 2;
//	printf("   1    2 ");
//	for (i = 3; i <= 10000-1 ; i += 2) {
//		if (isprime(i) == 0) {
//			printf("%4d ", i);
//			temp++;
//		}
//		if (temp == 20) {//ÿ�����ʮ��������
//			printf("\n");
//			temp = 0;
//		}
//	}
//
//	system("pause");
//}

/*6.10*/

#include <stdio.h>

void main() {
	int a[8];
	int i,t=0;
	for (i = 200; t < 8; i += 100,t++) {
		a[t] = i;
	}
	printf("input the staff's volume:");
	int vol;
	int salary;
	scanf_s("%d", &vol);
	salary = (int)vol * 0.09 + 200;
	for (t = 0; t < 7; t++) {
		if (vol >= a[t] && vol < a[t + 1]) {
			printf("the staff's sales volume %d is from %d to %d,his salary is %d\n", vol, a[t], a[t] + 99, salary);
			break;
		}
		if (vol >= a[7]) {
			printf("the staff's sales volume %d is more than 1000,his salary is %d\n", vol, salary);
			break;
		}
	}
	system("pause");
}



/*6,21*/
//#include <stdio.h>
//#include <string.h>
//
//void ifFirstClass(int eco);
//void ifEconomy(int first);
//int seat[10] = { 0 };
//void main() {
//	printf("Please type 1 for \"first class\"\n");
//	printf("Please type 2 for \"economy\"\n");
//	printf("Please type 3 to exit\n");
//	int input;
//	scanf_s("%d", &input);
//	while (input != 1 && input != 2 && input != 3) {
//		printf("Input error!Please type again\n");
//		scanf_s("%d", &input);
//	}
//	while (1) {
//		if (input == 1) {
//			ifFirstClass(1);
//		}
//		else if(input==2){
//			ifEconomy(1);
//		}
//		else {
//			break;
//		}
//		printf("Please type:");
//		scanf_s("%d", &input);
//	}
//	
//	system("pause");
//}
//
//void ifFirstClass(int eco) {
//	int temp = 0, code = 0;
//	for (; temp < 5; temp++) {
//		if (seat[temp] == 0) {
//			seat[temp] = 1;
//			printf("first class seat %d!\n", ++temp);
//			code = 1;
//			break;
//		}
//	}
//	char choice;
//	if (code == 0&& eco == 1) {
//		printf("sorry,the first class has no seats!\nDo you want to move to economy?('y'or'n')\n");
//		getchar();
//		scanf_s("%c", &choice);
//		if (choice == 'y') {
//			ifEconomy(0);
//		}
//		else {
//			printf("Next flight leaves in 3 hours.\n");
//		}
//	}
//	else if (code == 0 && eco == 0) {
//		printf("Sorry!There's no more seats!\nNext flight leaves in 3 hours.\n");
//	}
//}
//void ifEconomy(int first) {
//	int temp = 5, code = 0;
//	for (; temp < 10; temp++) {
//		if (seat[temp] == 0) {
//			seat[temp] = 1;
//			printf("economy seat %d!\n", ++temp);
//			code = 1;
//			break;
//		}
//	}
//	char choice;
//	if (code == 0 && first == 1) {
//		printf("sorry,the first class has no seats!\nDo you want to move to first class?('y'or'n')\n");
//		getchar();
//		scanf_s("%c", &choice);
//		if (choice == 'y') {
//			ifFirstClass(0);
//		}
//		else {
//			printf("Next flight leaves in 3 hours.\n");
//		}
//	}
//	else if (code == 0 && first == 0) {
//		printf("Sorry!There's no more seats!\nNext flight leaves in 3 hours.\n");
//	}
//}











//����
//#include <stdio.h>
//
//void print(int firstm,int year, int month);//��ӡ����
//int yearFirst(int year);//�жϸ����һ��
//int monthFirst(int year, int firsty, int month);//�жϸ��µ�һ��
//int leapyear(int year);
//
//void main() {
//
//	int year, month;
//	printf("Please input the year:");
//	scanf_s("%d", &year);
//	printf("Please input the month��");
//	scanf_s("%d", &month);
//
//	int firsty = yearFirst(year);
//	int firstm = monthFirst(year, firsty, month);
//	print(firstm, year, month);
//	system("pause");
//}
//
//void print(int firstm, int year, int month) {
//	int allday;
//	switch (month) {
//	case 1:printf("January                                         %d\n", year); allday = 31; break;
//	case 2:printf("Feburary                                        %d\n", year); allday = 28 + leapyear(year); break;
//	case 3:printf("March                                           %d\n", year); allday = 31; break;
//	case 4:printf("April                                           %d\n", year); allday = 30; break;
//	case 5:printf("May                                             %d\n", year); allday = 31; break;
//	case 6:printf("June                                            %d\n", year); allday = 30; break;
//	case 7:printf("July                                            %d\n", year); allday = 31; break;
//	case 8:printf("August                                          %d\n", year); allday = 31; break;
//	case 9:printf("September                                       %d\n", year); allday = 30; break;
//	case 10:printf("October                                         %d\n", year); allday = 31; break;
//	case 11:printf("November                                        %d\n", year); allday = 30; break;
//	case 12:printf("December                                        %d\n", year); allday = 31; break;
//	}
//	printf("SUN     MON     TUE     WED     THU     FRI     SAT\n");
//	int out = firstm;
//	while (out > 0) {
//		printf(" \t");
//		out--;
//	}
//	int i = 1;
//	for (; i <= 7 - firstm; i++) {
//		printf("%-8d", i);
//	}//�����һ��
//	int temp = 0;
//	printf("\n");
//	for (; i <= allday; i++) {//���漸��ѭ�����
//		printf("%-8d", i);
//		temp++;
//		if (temp == 7) {
//			printf("\n");
//			temp = 0;
//		}
//	}
//	printf("\n");
//}
//
//int yearFirst(int year) {
//	year = year % 100;
//	int firsty = (year-1+(year - 1) / 4 - (year - 1) / 100 + (year - 1) / 400 + 1) % 7 ;//��һ��ĵ�һ�����ܼ�
//	return firsty;
//}
//
//int monthFirst(int year, int firsty, int month) {
//	int firstm, days=0;
//	switch (month - 1) {
//		case 11:days += 30;
//		case 10:days += 31;
//		case 9:days += 30;
//		case 8:days += 31;
//		case 7:days += 31;
//		case 6:days += 30;
//		case 5:days += 31;
//		case 4:days += 30;
//		case 3:days += 31;
//		case 2:days += 28 + leapyear(year);
//		case 1:days += 31;
//		default:days += 0; break;
//	}
//	firstm = (days % 7+firsty)%7;//����µĵ�һ�����ܼ�
//	return firstm;
//}
//
//int leapyear(int year) {
//	if ((year % 4 == 0 && year % 100 != 0) || year % 400 == 0) {//�ж��Ƿ�Ϊ����
//		return 1;
//	}
//	else {
//		return 0;
//	}
//}