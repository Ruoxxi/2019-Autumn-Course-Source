#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>

#define SIZE 200

typedef struct {
	char name[20];
	int ID;
	int score;
}STUDENT;

static int sum = 15;//����ѧ������

void menu();//�˵�

STUDENT init();
void print();//���ȫ����Ϣ
void sortByID(); //��ID ����
void sortByname();//����������
void insert();//������Ϣ

void searchByname();//����������
void searchByID();//��ID����

void delByID();//��IDɾ��
void delByname();//������ɾ��

STUDENT stu[SIZE];//����ȫ�ֱ���

void main(){
	int i;	
	srand(time(NULL));
	for (i = 0; i < sum; i++) {
		stu[i] = init();
	}
	int direct;
	menu();
	scanf("%d", &direct);
	rewind(stdin);
	while (direct != 0){
		
		switch (direct) {
		case 1:print(); break;
		case 2:insert(); break;
		case 3:sortByname(); break;
		case 4:sortByID(); break;
		case 5:delByname(); break;
		case 6:delByID(); break;
		default:break;
		}
		menu();
		scanf("%d", &direct);
		rewind(stdin);
	}
	system("pause");
}

void menu() {

	printf("********************************************\n");
	printf("*                                          *\n");
	printf("* ��1�����ȫ����Ϣ   ��2������ѧ����Ϣ    *\n");
	printf("* ��3������������     ��4����ѧ������      *\n");
	printf("* ��5��������ɾ����Ϣ ��6����ѧ��ɾ����Ϣ  *\n");
	printf("*                     ��0���˳�            *\n");
	printf("*                                          *\n");
	printf("********************************************\n");
}

STUDENT init() {
	STUDENT stu;
	//srand(time(NULL));
	int i, j;
	for (j = 0; j < 4; j++) {
		stu.name[j] = 'A' + rand() % 26;
	}
	stu.name[4] = '\0';
	stu.ID = rand() % 100 + 1;
	stu.score = rand() % 101;

	return stu;
}

void print() {
	printf("ѧ��\tѧ������\t�ɼ�\n");
	int i = 0;
	while (stu[i].ID > 0 && i < sum) {
		printf("%d\t%s\t\t%d\n", stu[i].ID, stu[i].name, stu[i].score);
		i++;
	}
}

void sortByID() {
	int i, j;
	for (i = 0; i < sum; i++) {
		for (j = 0; j < sum-i-1; j++) {
			if (stu[j].ID < stu[j + 1].ID) {
				STUDENT temp;
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
	}
	print();
}

void sortByname() {
	int i, j;
	for (i = 0; i < sum; i++) {
		for (j = i; j < sum; j++) {
			if (strcmp(stu[j].name,stu[j+1].name)>0) {
				STUDENT temp;
				temp = stu[j];
				stu[j] = stu[j + 1];
				stu[j + 1] = temp;
			}
		}
	}
	print();
}
void insert() {
	printf("Please input the ID name score:");
	scanf("%d %s %d", &stu[sum].ID, &stu[sum].name, &stu[sum].score);
	rewind(stdin);
	sum++;
	printf("Insert succeed!\n");
}

void delByID() {
	int temp = 0;
	printf("Please input the ID to delete:");
	int id;
	scanf("%d", &id);
	rewind(stdin);
	int i = 0;

	while (i < sum) {
		if (stu[i].ID == id) {
			temp = 1;
			printf("Are you sure to delete ��%d %s %d��?('y'/'n')", stu[i].ID, stu[i].name, stu[i].score);
			char input;
			scanf("%c", &input);
			rewind(stdin);
			if (input == 'y' || input == 'Y') {
				stu[i].ID = 0;
				printf("succees!\n");
				sum--;
			}	
			return;
		}
		i++;
	}
	if (temp == 0) {
		printf("ID not found!\n");
	}
}

void delByname() {
	int temp = 0;
	printf("Please input the name to delete:");
	char name[20];
	scanf("%s", name);
	rewind(stdin);
	int i = 0;

	while (i < sum) {
		if (strcmp(stu[i].name, name)==0) {
			temp = 1;
			printf("Are you sure to delete ��%d %s %d��?('y'/'n')", stu[i].ID, stu[i].name, stu[i].score);
			char input;
			scanf("%c", &input);
			if (input == 'y' || input == 'Y') {
				stu[i].ID = 0;
				printf("succees!\n");
				sum--;
			}
			return;
		}
		i++;
	}
	if (temp == 0) {
		printf("Name not found!\n");
	}
}
void searchByID() {
	print();
	printf("Please input the ID:");
	int id;
	scanf("%d", &id);
	rewind(stdin);
	int i = 0;
	int temp = 0;
	while (i < sum) {
		if (stu[i].ID == id) {
			temp = 1;
			printf("%d\t%s\t\t%d\n", stu[i].ID, stu[i].name, stu[i].score);
			return;
		}
		i++;
	}
	if (temp == 0) {
		printf("ID not found!\n");
	}
	return temp;
}

void searchByname() {
	print();
	printf("Please input the name:");
	char names[20];
	scanf("%s", &names);
	rewind(stdin);
	//fflush(stdin);
	int i = 0;
	int temp = 0;
	while (i < sum) {
		if (strcmp(stu[i].name, names)==0) {
			temp = 1;
			printf("%d\t%s\t\t%d\n", stu[i].ID, stu[i].name, stu[i].score);
			return;
		}
		i++;
	}
	if (temp == 0) {
		printf("Name not found!\n");
	}
}