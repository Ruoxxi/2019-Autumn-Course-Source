#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <windows.h>

int hareMove(int i);
int torMove(int i);

void main() {
	int harPosition = 1;
	int torPosition = 1;
	int second = 0;
	printf("BANG !!!!!\nAND THEY'RE OFF !!!!!\n");

	second++;
	srand(time(NULL));
	int iT = rand() % 10 + 1;
	int iH = rand() % 10 + 1;

	int posH = hareMove(iH);
	int torH = torMove(iT);

	harPosition += posH;
	torPosition += torH;

	while (harPosition < 70 && torPosition < 70) {
		
		
		int i;
		if (harPosition == torPosition) {
			for (i = 1; i <= 70; i++) {//��ӡouch
				if (i == harPosition) {
					printf("OUCH!!!");
				}
				else {
					printf(" ");
				}
			}
			printf("\n");
		}
		else {
			for (i = 1; i <= 70; i++) {//��ӡ����
				if (i == harPosition) {
					printf("H");
				}
				else if (i == torPosition) {
					printf("T");
				}
				else {
					printf(" ");
				}
			}
			printf("\n");
		}
		//Sleep(1000);
		second++;

		int iT = rand() % 10 + 1;

		int iH = rand() % 10 + 1;

		int posH = hareMove(iH);
		int torH = torMove(iT);

		harPosition += posH;
		torPosition += torH;

		if (harPosition < 1) {
			harPosition = 1;
		}
		if (torPosition < 1) {
			torPosition = 1;
		}
		

	}
	if (harPosition >= 70 && torPosition >= 70) {
		printf("It's a tie.\n");
	}
	else if (harPosition >= 70) {
		printf("Hare wins.Yuch!\n");
	}
	else if (torPosition >= 70) {
		printf("TORTOISE WINS!!!YAY!!!\n");
	}
	printf("All in %d seconds\n", second);
	system("pause");
}
int hareMove(int i) {
	switch (i)
	{
	case 1:
	case 2:return 0;
	case 3:
	case 4:return 9;
	case 5:return -12;
	case 6:
	case 7:
	case 8:return 1;
	case 9:
	case 10:return -2;
	default:
		break;
	}
}

int torMove(int i) {
	switch (i)
	{
	case 1:
	case 2:
	case 3:
	case 4:
	case 5:return 3;
	case 6:
	case 7:return -6;
	case 8:
	case 9:
	case 10:return 1;
	default:
		break;
	}
}
