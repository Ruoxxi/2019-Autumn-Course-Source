You must have the Java SDK 1.4.x to run or compile MarieSim.
This software is available at no charge from http://java.sun.com
 
To run MarieSim: jar xvf MarieSim.jar
                 java MarieSim1

Note: If you are having trouble running MarieSim using only the class files from the jar file (e.g., your system hangs), recompile the simulator using the compilation command.

To compile MarieSim: jar xvf MarieSource.jar  
                     javac MarieSim1.java

See MarieGuide.pdf or MarieGuide.doc for instructions for running MarieSim.

MarieSim Version 1.1 - April 7, 2003
  Enhancement: Close button added to view panes.
               Input register changes color when input is needed.
  Bug fix: Corrected breakpoint processing when input solicited.